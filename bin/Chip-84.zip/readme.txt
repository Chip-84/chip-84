To convert .c8 files, drag and drop it onto Chip-84 Converter.exe (MAKE SURE YOUR FILE'S NAME IS <= 8 CHARACTERS)
then transfer the output .8xv file into your TI-84 Plus CE.

Use 0, DECIMAL, NEGATIVE, ENTER, 1, 2, 3, PLUS, 4, 5, 6, MINUS, 7, 8, 9, TIMES for in-game controls.